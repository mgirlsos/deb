# ./agent_bin folder
This folder is meant to hold all the scripts that will be called either directly by the Zabbix-agent on the wrapper script.