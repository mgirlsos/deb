#!/bin/bash

echo "THIS SCRIPT SHOULD NOT BE USED EVER!!!!"

exit 1
